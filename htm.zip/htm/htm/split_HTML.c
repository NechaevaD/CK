#define _CRT_SECURE_NO_WARNINGS
#include "split_HTML.h"
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 8192
#define MAX_TAG_LEN 100
#define MAX_STACK_SIZE 100

int is_block_tag(const char* tag, const char* block_tags[], int num_block_tags) {
    for (int i = 0; i < num_block_tags; i++) {
        if (strncmp(tag + 1, block_tags[i], strlen(block_tags[i])) == 0 ||
            (tag[1] == '/' && strncmp(tag + 2, block_tags[i], strlen(block_tags[i])) == 0)) {
            return 1;
        }
    }
    return 0;
}

void close_open_tags(char output[], int* output_len, char stack[][MAX_TAG_LEN], int* stack_len) {
    for (int i = *stack_len - 1; i >= 0; i--) {
        if (stack[i][1] != '/') {
            strcat(output + *output_len, "</");
            strncat(output + *output_len, stack[i] + 1, strlen(stack[i]) - 2);
            strcat(output + *output_len, ">");
            *output_len += strlen(output + *output_len);
        }
    }
}

void write_output_to_file(char output[], int* output_len, int* number_html, char stack[][MAX_TAG_LEN], int* stack_len) {
    char filename[100];
    snprintf(filename, sizeof(filename), "HTML-%d.html", *number_html);
    FILE* out_file = fopen(filename, "w");
    if (out_file != NULL) {
        fwrite(output, 1, *output_len, out_file);
        fclose(out_file);
    }
    (*number_html)++;
    memset(output, 0, BUFFER_SIZE);
    *output_len = 0;
    for (int i = 0; i < *stack_len; i++) {
        strcat(output + *output_len, stack[i]);
        *output_len += strlen(stack[i]);
    }
}

int split_HTML(FILE* html, int max_len) {
    const char* block_tags[] = { "p", "b", "strong", "i", "ul", "ol", "div", "span" };
    const int num_block_tags = 8;

    char output[BUFFER_SIZE] = { 0 };
    int output_len = 0;

    char tag[MAX_TAG_LEN] = { 0 };
    int tag_len = 0;

    char stack[MAX_STACK_SIZE][MAX_TAG_LEN] = { {0} };
    int stack_len = 0;

    int number_html = 0;
    int in_tag = 0;

    fseek(html, 0, SEEK_SET);
    char ch;
    while ((ch = fgetc(html)) != EOF) {
        if (ch == '<') {
            in_tag = 1;
            tag_len = 0;
            tag[tag_len++] = ch;
        }
        else if (ch == '>') {
            in_tag = 0;
            tag[tag_len++] = ch;
            tag[tag_len] = '\0';

            if (is_block_tag(tag, block_tags, num_block_tags)) {
                if (tag[1] == '/') {
                    if (stack_len > 0 && strncmp(stack[stack_len - 1] + 1, tag + 2, strlen(tag) - 3) == 0) {
                        stack_len--;
                    }
                }
                else {
                    strcpy(stack[stack_len++], tag);
                }
            }

            if (output_len + tag_len < max_len - stack_len * MAX_TAG_LEN) {
                strcpy(output + output_len, tag);
                output_len += tag_len;
            }
            else {
                close_open_tags(output, &output_len, stack, &stack_len);
                write_output_to_file(output, &output_len, &number_html, stack, &stack_len);
                strcpy(output + output_len, tag);
                output_len += tag_len;
            }
        }
        else if (in_tag) {
            tag[tag_len++] = ch;
        }
        else {
            if (output_len + 1 < max_len - stack_len * MAX_TAG_LEN) {
                output[output_len++] = ch;
            }
            else {
                close_open_tags(output, &output_len, stack, &stack_len);
                write_output_to_file(output, &output_len, &number_html, stack, &stack_len);
                output[output_len++] = ch;
            }
        }
    }

    if (output_len > 0) {
        close_open_tags(output, &output_len, stack, &stack_len);
        write_output_to_file(output, &output_len, &number_html, stack, &stack_len);
    }

    return 1;
}
