#pragma once
#pragma once
#ifndef SPLIT_HTML_H
#define SPLIT_HTML_H

#include <stdio.h>

int split_HTML(FILE* html, int max_len);

#endif // SPLIT_HTML_H

